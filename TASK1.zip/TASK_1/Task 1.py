import dask.dataframe as dd
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the CSV file
df = dd.read_csv("C:\\Users\\Lenovo\\OneDrive\\Desktop\\CODTECH\\TASKS\\TASK_1\\dataset_task1.csv", assume_missing=True)

# Fix datetime column format
df["pickup_date"] = dd.to_datetime(
    df["tpep_pickup_datetime"],
    format="%d-%m-%y %H.%M",
    errors="coerce"
).dt.floor("D")  # Floor to remove time and keep date only

# 1. Average total_amount by payment_type
avg_total = df.groupby("payment_type")["total_amount"].mean().reset_index()
avg_total["Metric"] = "Average_Total_Amount"
avg_total = avg_total.rename(columns={"payment_type": "Key", "total_amount": "Value"})

# 2. Trip count by payment_type
trip_count = df.groupby("payment_type").size().reset_index()
trip_count = trip_count.rename(columns={"payment_type": "Key", 0: "Value"})
trip_count["Metric"] = "Trip_Count"

# 3. Average trip_distance by payment_type
avg_distance = df.groupby("payment_type")["trip_distance"].mean().reset_index()
avg_distance["Metric"] = "Avg_Trip_Distance"
avg_distance = avg_distance.rename(columns={"payment_type": "Key", "trip_distance": "Value"})

# 4. Average tip_amount by payment_type
avg_tip = df.groupby("payment_type")["tip_amount"].mean().reset_index()
avg_tip["Metric"] = "Avg_Tip_Amount"
avg_tip = avg_tip.rename(columns={"payment_type": "Key", "tip_amount": "Value"})

# 5. Total fare_amount by PULocationID (top 10)
total_fare_by_pu = df.groupby("PULocationID")["fare_amount"].sum().reset_index()
total_fare_by_pu = total_fare_by_pu.nlargest(10, "fare_amount")
total_fare_by_pu["Metric"] = "Total_Fare_by_PULocationID"
total_fare_by_pu = total_fare_by_pu.rename(columns={"PULocationID": "Key", "fare_amount": "Value"})

# 6. Average total_amount by VendorID
avg_total_by_vendor = df.groupby("VendorID")["total_amount"].mean().reset_index()
avg_total_by_vendor["Metric"] = "Avg_Total_Amount_by_Vendor"
avg_total_by_vendor = avg_total_by_vendor.rename(columns={"VendorID": "Key", "total_amount": "Value"})

# 7. Daily trip count (top 10 earliest days)
daily_trip_count = df.groupby("pickup_date").size().reset_index()
daily_trip_count = daily_trip_count.rename(columns={"pickup_date": "Key", 0: "Value"})
daily_trip_count["Metric"] = "Daily_Trip_Count"
daily_trip_count = daily_trip_count.nsmallest(10, "Key")

# Combine all results
combined_ddf = dd.concat([
    avg_total,
    trip_count,
    avg_distance,
    avg_tip,
    total_fare_by_pu,
    avg_total_by_vendor,
    daily_trip_count
], axis=0)

# Compute Dask to get Pandas DataFrame
combined_df = combined_ddf.compute()

# Save result to CSV
combined_df[["Metric", "Key", "Value"]].to_csv("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/op_task1.csv", index=False)
print("Data computation completed and saved !")

# VISUALIZATIONS
# Set seaborn style
sns.set_theme(style="whitegrid")

# 1. Average total amount by payment_type
plt.figure(figsize=(8, 4))
sns.barplot(data=combined_df[combined_df["Metric"] == "Average_Total_Amount"], x="Key", y="Value")
plt.title("Average Total Amount by Payment Type")
plt.ylabel("Average Amount ($)")
plt.xlabel("Payment Type")
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/plot_avg_total_amount.png")
plt.close()
plt.show()

# 2. Trip count by payment_type
plt.figure(figsize=(8, 4))
sns.barplot(data=combined_df[combined_df["Metric"] == "Trip_Count"], x="Key", y="Value")
plt.title("Trip Count by Payment Type")
plt.ylabel("Trip Count")
plt.xlabel("Payment Type")
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/plot_trip_count.png")
plt.close()
plt.show()

# 3. Avg trip distance
plt.figure(figsize=(8, 4))
sns.barplot(data=combined_df[combined_df["Metric"] == "Avg_Trip_Distance"], x="Key", y="Value")
plt.title("Average Trip Distance by Payment Type")
plt.ylabel("Avg Distance (miles)")
plt.xlabel("Payment Type")
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/plot_avg_trip_distance.png")
plt.close()
plt.show()

# 4. Avg tip amount
plt.figure(figsize=(8, 4))
sns.barplot(data=combined_df[combined_df["Metric"] == "Avg_Tip_Amount"], x="Key", y="Value")
plt.title("Average Tip Amount by Payment Type")
plt.ylabel("Average Tip ($)")
plt.xlabel("Payment Type")
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/plot_avg_tip_amount.png")
plt.close()
plt.show()

# 5. Total fare amount by top 10 PU locations
plt.figure(figsize=(10, 5))
sns.barplot(data=combined_df[combined_df["Metric"] == "Total_Fare_by_PULocationID"], x="Key", y="Value")
plt.title("Total Fare Amount by PULocationID (Top 10)")
plt.ylabel("Total Fare ($)")
plt.xlabel("PU Location ID")
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/plot_total_fare_pu.png")
plt.close()
plt.show()

# 6. Avg total amount by VendorID
plt.figure(figsize=(6, 4))
sns.barplot(data=combined_df[combined_df["Metric"] == "Avg_Total_Amount_by_Vendor"], x="Key", y="Value")
plt.title("Avg Total Amount by VendorID")
plt.ylabel("Average Total ($)")
plt.xlabel("Vendor ID")
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/plot_avg_total_vendor.png")
plt.close()
plt.show()

# 7. Daily trip count
plt.figure(figsize=(10, 5))
sns.lineplot(data=combined_df[combined_df["Metric"] == "Daily_Trip_Count"], x="Key", y="Value", marker="o")
plt.title("Daily Trip Count (Earliest 10 Days)")
plt.ylabel("Trip Count")
plt.xlabel("Date")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_1/outputs_task1/plot_daily_trip_count.png")
plt.close()
plt.show()

print("All visualizations saved successfully !")