import pandas as pd
import matplotlib.pyplot as plt
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk
import os

# Download VADER lexicon
nltk.download('vader_lexicon')

# Define output directory
output_dir = "C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_4/outputs_task4"
os.makedirs(output_dir, exist_ok=True)

# Load data with specified headers { dataset must have 'Text' header }
df = pd.read_csv("C:\\Users\\Lenovo\\OneDrive\\Desktop\\CODTECH\\TASKS\\TASK_4\\dataset_task 4.csv")

# Sentiment Analysis
sia = SentimentIntensityAnalyzer()
df['VaderScore'] = df['Text'].apply(lambda x: sia.polarity_scores(x)['compound'])

# Categorize
df['Label'] = df['VaderScore'].apply(lambda x: 'Positive' if x > 0 else ('Negative' if x < 0 else 'Neutral'))

# Show results
print(df[['Text', 'VaderScore', 'Label']])

# Visualization 1: Pie Chart for VADER Sentiment Label Distribution
label_counts = df['Label'].value_counts()
plt.figure(figsize=(8, 6))
plt.pie(label_counts, labels=label_counts.index, colors=['#36A2EB', '#FF6384', '#FFCE56'], 
        autopct='%1.1f%%', startangle=140)
plt.title('VADER Sentiment Label Distribution')
plt.axis('equal')  # Equal aspect ratio ensures pie is drawn as a circle
plt.savefig(os.path.join(output_dir, 'vader_sentiment_pie.png'))
plt.close()

# Visualization 2: Bar Chart for Original Sentiment Score Distribution
sentiment_counts = df['TweetSentiment'].value_counts().sort_index()
plt.figure(figsize=(8, 6))
plt.bar(['Negative (0)', 'Neutral (2)', 'Positive (4)'], 
        [sentiment_counts.get(0, 0), sentiment_counts.get(2, 0), sentiment_counts.get(4, 0)], 
        color=['#FF6384', '#36A2EB', '#FFCE56'])
plt.xlabel('Sentiment Score')
plt.ylabel('Count')
plt.title('Original Sentiment Score Distribution')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.savefig(os.path.join(output_dir, 'original_sentiment_bar.png'))
plt.close()

# Visualization 3: Bar Chart for Sentiment by Top 5 Topics
top_topics = df['Subject'].value_counts().head(5).index
topic_sentiment = df[df['Subject'].isin(top_topics)].groupby(['Subject', 'Label']).size().unstack(fill_value=0)
plt.figure(figsize=(10, 6))
x = range(len(top_topics))
width = 0.25
plt.bar([i - width for i in x], topic_sentiment.get('Positive', [0]*len(top_topics)), 
        width, label='Positive', color='#FFCE56')
plt.bar(x, topic_sentiment.get('Neutral', [0]*len(top_topics)), 
        width, label='Neutral', color='#36A2EB')
plt.bar([i + width for i in x], topic_sentiment.get('Negative', [0]*len(top_topics)), 
        width, label='Negative', color='#FF6384')
plt.xlabel('Topic')
plt.ylabel('Tweet Count')
plt.title('Sentiment Distribution by Top 5 Topics')
plt.xticks(x, top_topics, rotation=45)
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'sentiment_by_topic_bar.png'))
plt.close()

print("All visualizations saved successfully !")

# Save insights
df.to_csv('C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_4/op_task4.csv', index=False)
print("All insights saved successfully !!")