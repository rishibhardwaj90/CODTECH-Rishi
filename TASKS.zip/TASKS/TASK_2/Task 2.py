import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

# Load dataset
df = pd.read_csv("C:\\Users\\Lenovo\\OneDrive\\Desktop\\CODTECH\\TASKS\\TASK_2\\dataset_task 2.csv")

# Select relevant features and target
df = df[["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Survived"]]

# Convert categorical to numeric
df["Sex"] = df["Sex"].map({"male": 0, "female": 1})

# Handle missing values
df["Age"] = df["Age"].fillna(df["Age"].median())
df["Fare"] = df["Fare"].fillna(df["Fare"].median())

# TRAINING/TESTING

# Define features and target
X = df.drop("Survived", axis=1)
y = df["Survived"]

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Predict and evaluate
predictions = model.predict(X_test)
print(classification_report(y_test, predictions))

# Get prediction probabilities for class 1 (Survived)
prediction_probs = model.predict_proba(X_test)[:, 1]

# Combine test features, actual, predicted, and probability
output_df = X_test.copy()
output_df["Actual_Survived"] = y_test.values
output_df["Predicted_Survived"] = predictions
output_df["Survival_Probability"] = prediction_probs.round(4)  # Rounded for neatness

# Sort by survival probability (ascending)
output_df = output_df.sort_values(by="Survival_Probability", ascending=True)

# Save to CSV
output_df.to_csv("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_2/op_task2.csv", index=False)
print("Sorted prediction results saved.")

# VISUALIZATIONS

# Set seaborn style
sns.set_theme(style="whitegrid")

# 1. Count plot of Survived
plt.figure(figsize=(6, 4))
sns.countplot(data=df, x="Survived", hue="Survived", palette="Set2", legend=False)
plt.title("Survival Count")
plt.xlabel("Survived (0 = No, 1 = Yes)")
plt.ylabel("Count")
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_2/outputs_task2/plot_survival_count.png")
plt.close()
plt.show()

# 2. Survival count by Sex
plt.figure(figsize=(6, 4))
sns.countplot(data=df, x="Sex", hue="Survived", palette="Set1")
plt.title("Survival by Sex")
plt.xlabel("Sex (0 = Male, 1 = Female)")
plt.ylabel("Count")
plt.legend(title="Survived")
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_2/outputs_task2/plot_survival_by_sex.png")
plt.close()
plt.show()

# 3. Age distribution
plt.figure(figsize=(8, 4))
sns.histplot(data=df, x="Age", bins=30, kde=True, hue="Survived", multiple="stack", palette="pastel")
plt.title("Age Distribution by Survival")
plt.xlabel("Age")
plt.ylabel("Count")
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_2/outputs_task2/plot_age_distribution.png")
plt.close()
plt.show()

# 4. Correlation heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(df.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Feature Correlation Heatmap")
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_2/outputs_task2/plot_correlation_heatmap.png")
plt.close()
plt.show()

# 5. Featuring important visualization
feature_importances = pd.Series(model.feature_importances_, index=X.columns)
plt.figure(figsize=(8, 5))
feature_importances.sort_values().plot(kind='barh', color='skyblue')
plt.title("Feature Importances from Random Forest")
plt.xlabel("Importance Score")
plt.tight_layout()
plt.savefig("C:/Users/Lenovo/OneDrive/Desktop/CODTECH/TASKS/TASK_2/outputs_task2/plot_feature_importance.png")
plt.close()
plt.show()

print("All visualizations saved successfully !")